import os
import json
import uuid
import asyncio
import datetime
import logging
import time
import random
import re
from typing import Dict, Any, Optional, Tuple, List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from google.cloud import bigquery
from github import Github, GithubException

import vertexai
from vertexai.generative_models import GenerativeModel

# ==============================================================================
# ⚙️ ENTERPRISE CONFIGURATION
# ==============================================================================
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sentinel-insight")

app = FastAPI(title="Sentinel-Insight")
app.mount("/static", StaticFiles(directory="static"), name="static")

PROJECT_ID = os.environ.get("GCP_PROJECT")
REGION = os.environ.get("GCP_REGION", "global")
REPO_NAME = os.environ.get("REPO_NAME")
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN")
AUDIT_TABLE = os.environ.get(
    "AUDIT_TABLE", f"{PROJECT_ID}.sentinel_audit.insight_audit_log"
)

AI_MODEL_HEAVY_NAME = os.environ.get("AI_MODEL_HEAVY", "gemini-2.5-flash")
AI_MODEL_LITE_NAME = os.environ.get("AI_MODEL_LITE", "gemini-2.5-flash-lite")

COST_PER_TB = 6.25  # Standard BigQuery On-Demand Pricing

bq_client: Optional[bigquery.Client] = None
model_heavy = None
model_lite = None

try:
    if PROJECT_ID:
        bq_client = bigquery.Client(project=PROJECT_ID)
        vertexai.init(project=PROJECT_ID, location=REGION)
        model_heavy = GenerativeModel(AI_MODEL_HEAVY_NAME)
        model_lite = GenerativeModel(AI_MODEL_LITE_NAME)
        logger.info(
            f"✅ [Init] Vertex AI Online. Heavy: {AI_MODEL_HEAVY_NAME} | Lite: {AI_MODEL_LITE_NAME}"
        )
except Exception as e:
    logger.error(f"❌ [Init Fail] Failed to initialize GCP/Vertex clients: {e}")


# ==============================================================================
# 📝 OBSERVABILITY & TRAFFIC SMOOTHING
# ==============================================================================
async def stream_log(
    ws: WebSocket, severity: str, message: str, trace_id: str, is_error: bool = False
):
    """Streams emoji-rich logs directly to the UI and prints to stdout."""
    log_entry = f"[{trace_id}] {severity} - {message}"
    if is_error:
        logger.error(log_entry)
        await ws.send_json({"status": "error", "message": message})
    else:
        logger.info(log_entry)
        await ws.send_json({"status": "thinking", "message": message})


def smooth_traffic(trace_id: str):
    """Mitigates Vertex AI 429 Too Many Requests errors by pacing API calls."""
    logger.info(
        f"⏳ 🚦 [Traffic] Pacing AI request (3s) to prevent 429 Rate Limit burst... [{trace_id}]"
    )
    time.sleep(3)


def generate_content_with_retry(
    model_instance, prompt: str, trace_id: str, max_retries: int = 5
):
    """Executes Vertex AI generation with Exponential Backoff for 429 errors."""
    base_delay = 5
    for attempt in range(max_retries):
        try:
            smooth_traffic(trace_id)
            response = model_instance.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            error_msg = str(e).lower()
            if "429" in error_msg or "resource exhausted" in error_msg:
                if attempt == max_retries - 1:
                    logger.error(
                        f"🚨 🚦 [Traffic] Max retries reached for 429 error. Failing. [{trace_id}]"
                    )
                    raise e
                sleep_time = (base_delay * (2**attempt)) + random.uniform(0, 2)
                logger.warning(
                    f"⚠️ 🚦 [Traffic] 429 Quota Hit. Retrying in {sleep_time:.2f}s... [{trace_id}]"
                )
                time.sleep(sleep_time)
            else:
                raise e


def prune_markdown(text: str, lang: str = "sql") -> str:
    """Strips markdown formatting from AI responses."""
    if text.startswith("```"):
        try:
            return text.split("\n", 1)[1].rsplit("\n", 1)[0]
        except IndexError:
            return text.replace(f"```{lang}", "").replace("```", "")
    return text


def log_to_audit_table(
    trace_id: str, intent: str, status: str, event_log: dict, user_email: str
):
    """Writes telemetry directly to the Terraform-provisioned BigQuery Audit table."""
    if not bq_client:
        return
    row = {
        "trace_id": trace_id,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "user_intent": intent,
        "status": status,
        "event_log": json.dumps({"user": user_email, **event_log}),
    }
    try:
        bq_client.insert_rows_json(AUDIT_TABLE, [row])
    except Exception as e:
        logger.error(f"❌ [Audit Fail] Failed to write ledger: {e}")


# ==============================================================================
# 🧠 THE AGENT SWARM FUNCTIONS
# ==============================================================================
async def agent_classify_intent(intent: str, trace_id: str, ws: WebSocket) -> str:
    """Agent 0: Classifies the user's intent into GREETING, EXPLORE, or BUILD."""
    await stream_log(
        ws, "INFO", "▶️ 🧠 [Agent 0: Router] Analyzing cognitive intent...", trace_id
    )
    prompt = f"""
    Analyze the user's intent: "{intent}"
    Classify into exactly one of these categories:
    - GREETING: If they say hi, hello, help, or ask what you can do.
    - BUILD: If they explicitly ask to deploy, create a table, create a view, terraform, or "build it".
    - EXPLORE: If they are asking for data, insights, or just running a query.
    Output ONLY the exact category word.
    """
    category = await asyncio.to_thread(
        generate_content_with_retry, model_lite, prompt, trace_id
    )
    category = category.strip().upper()
    await stream_log(
        ws, "INFO", f"⏹️ 🧠 [Agent 0: Router] Intent classified as: {category}", trace_id
    )
    return category if category in ["GREETING", "BUILD", "EXPLORE"] else "EXPLORE"


async def agent_draft_sql(
    intent: str, chat_history: List[Dict], trace_id: str, ws: WebSocket
) -> str:
    """Agent 1: Writes the initial SQL based on intent, history, and strict data typing."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 🧠 [Agent 1: SQL Architect] Initiating translation of business intent to SQL...",
        trace_id,
    )
    history_context = "\n".join(
        [f"{msg['role'].upper()}: {msg['content']}" for msg in chat_history[-5:]]
    )

    prompt = f"""
    You are an expert BigQuery Data Engineer. 
    Recent Conversation History:
    {history_context}
    
    Current Business Intent: "{intent}"
    
    Task: Write a highly optimized, complex BigQuery Standard SQL SELECT statement to fulfill this intent.
    
    CRITICAL GOVERNANCE REQUIREMENTS:
    1. TARGET DATASET CONTEXT: This query will eventually be deployed as a final consumption table in `sentinel_marts`.
    2. STRICT TYPING: You MUST ensure all calculated metrics, aggregations, and derived columns are explicitly cast to their proper native BigQuery data types using SAFE_CAST. Do not rely on implicit typing.
    3. EFFICIENCY: Query ONLY the necessary information. Do not select columns that are not relevant.
    4. TABLE PRIORITIZATION: Prioritize tables explicitly mentioned by the user. If vague, assume standard schema naming conventions.
    
    Output ONLY the raw SQL code. No markdown formatting.
    """
    sql = await asyncio.to_thread(
        generate_content_with_retry, model_heavy, prompt, trace_id
    )
    sql = prune_markdown(sql, "sql")
    await stream_log(
        ws,
        "INFO",
        "⏹️ 🧠 [Agent 1: SQL Architect] Successfully drafted strictly-typed SQL logic.",
        trace_id,
    )
    return sql


async def sandbox_dry_run_and_count(
    sql: str, trace_id: str, ws: WebSocket
) -> Tuple[bool, str, float, int, list]:
    """Validates SQL, calculates cost, extracts schema, and checks row bounds."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 🧪 [Sandbox] Initiating BigQuery Dry-Run and Cost Analysis...",
        trace_id,
    )

    job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)
    try:
        # 1. Dry Run for Syntax, Cost, and Schema
        dry_run_job = await asyncio.to_thread(
            bq_client.query, sql, job_config=job_config
        )
        bytes_processed = dry_run_job.total_bytes_processed or 0
        cost = (bytes_processed / (1024**4)) * COST_PER_TB
        schema = [
            {"name": field.name, "type": field.field_type}
            for field in dry_run_job.schema
        ]

        await stream_log(
            ws,
            "INFO",
            f"⏹️ 🧪 [Sandbox] Dry-run passed. Bytes processed: {bytes_processed}. Checking row limits...",
            trace_id,
        )

        # 2. Fast Count Execution
        count_sql = f"SELECT COUNT(*) as cnt FROM ({sql})"
        count_job = await asyncio.to_thread(bq_client.query, count_sql)
        res = list(count_job.result())
        row_count = res[0].cnt if res else 0

        return True, "Valid", cost, row_count, schema
    except Exception as e:
        error_msg = str(e)
        await stream_log(
            ws,
            "WARNING",
            f"⚠️ 🧪 [Sandbox] FAILED: Target anomaly detected -> {error_msg}",
            trace_id,
        )
        return False, error_msg, 0.0, 0, []


async def agent_heal_sql(
    intent: str, bad_sql: str, error_msg: str, trace_id: str, ws: WebSocket
) -> str:
    """Agent 1b: Heals the SQL based on BigQuery error messages."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 🚑 [Agent 1: Healer] Attempting autonomous SQL repair based on sandbox telemetry...",
        trace_id,
    )
    prompt = f"""
    You are an expert BigQuery Data Engineer. Your previous SQL failed a dry-run.
    Business Intent: "{intent}"
    Failed SQL: {bad_sql}
    BigQuery Error: {error_msg}
    Task: Fix the SQL query so it successfully executes. Output ONLY the raw SQL code. No markdown.
    """
    healed_sql = await asyncio.to_thread(
        generate_content_with_retry, model_heavy, prompt, trace_id
    )
    return prune_markdown(healed_sql, "sql")


async def agent_draft_schema_json(
    schema_fields: list, table_name: str, trace_id: str, ws: WebSocket
) -> str:
    """Agent: Formats the extracted BQ schema into a strict JSON array (Sentinel-Forge spec)."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 🧩 [Schema Design] Synthesizing strict JSON Schema definition...",
        trace_id,
    )
    prompt = f"""
    Format this BigQuery schema into a strictly valid JSON array of objects.
    Target Table: {table_name}
    Extracted Fields: {json.dumps(schema_fields)}
    
    Requirements:
    1. Output strictly a JSON list of objects containing `name`, `type`, `mode` (NULLABLE), and a `description`.
    2. Add a `defaultValueExpression` of "NULL" to every field.
    Output JSON Array only.
    """
    schema_json = await asyncio.to_thread(
        generate_content_with_retry, model_lite, prompt, trace_id
    )
    return prune_markdown(schema_json, "json")


async def agent_draft_terraform(
    sql: str,
    table_id: str,
    schema_path: str,
    user_email: str,
    trace_id: str,
    ws: WebSocket,
) -> str:
    """Agent 2: Wraps the SQL into a Terraform BigQuery View resource with explicit Labels."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 🏗️ [Agent 2: TF Architect] Wrapping validated SQL into Infrastructure-as-Code (HCL)...",
        trace_id,
    )
    safe_user = user_email.replace("@", "_at_").replace(".", "_")

    prompt = f"""
    You are an expert DevOps Engineer writing Terraform HCL.
    
    Task: Create a `google_bigquery_table` resource that deploys a materialized table.
    Table ID: "{table_id}"
    Description: "Autonomously generated analytics table via Sentinel-Insight"
    
    SQL Query to execute for the table data:
    ```sql
    {sql}
    ```
    
    Requirements:
    1. STRICT DATASET: The `dataset_id` property MUST strictly be "sentinel_marts".
    2. LABELS: You MUST include the following labels block:
       labels = {{
         created_by = "{safe_user}"
         created_via = "sentinel_insights"
       }}
    3. SCHEMA: Point the schema attribute to: `schema = file("${{path.module}}/{schema_path}")`
    4. Output STRICTLY valid HCL code. No markdown.
    """
    hcl = await asyncio.to_thread(
        generate_content_with_retry, model_heavy, prompt, trace_id
    )
    return prune_markdown(hcl, "hcl")


async def execute_and_format_results(sql: str, trace_id: str, ws: WebSocket) -> str:
    """Executes the dry-run-validated SQL and formats it into a Glassmorphism HTML table."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 📊 [Execution] Querying BigQuery engine and formatting results...",
        trace_id,
    )
    try:
        query_job = await asyncio.to_thread(bq_client.query, sql)
        results = await asyncio.to_thread(query_job.result)

        html = "<div class='overflow-x-auto w-full mt-4 rounded-xl border border-white/10 shadow-lg'>"
        html += "<table class='w-full text-left text-xs text-gray-300 border-collapse'>"

        headers = [field.name for field in results.schema]
        html += "<thead class='bg-white/5 text-emerald-400 font-mono'><tr>"
        for header in headers:
            html += f"<th class='px-4 py-3 border-b border-white/10'>{header}</th>"
        html += "</tr></thead><tbody>"

        row_count = 0
        for row in results:
            row_count += 1
            html += "<tr class='hover:bg-white/5 transition-colors duration-200'>"
            for val in row:
                html += f"<td class='px-4 py-3 border-b border-white/5'>{str(val)}</td>"
            html += "</tr>"

        html += "</tbody></table></div>"

        if row_count == 0:
            html = "<div class='text-sm text-gray-400 italic mt-2'>Query returned zero results.</div>"

        await stream_log(
            ws,
            "INFO",
            "⏹️ 📊 [Execution] Results successfully fetched and formatted.",
            trace_id,
        )
        return html
    except Exception as e:
        raise Exception(f"Failed to fetch results: {e}")


# ==============================================================================
# 📦 GIT INJECTOR (Multi-File for TF & JSON)
# ==============================================================================
async def inject_and_create_pr(
    repo_name: str,
    token: str,
    branch_name: str,
    files: dict,
    title: str,
    trace_id: str,
    user_email: str,
    ws: WebSocket,
) -> str:
    """Commits multiple files (TF and JSON) and opens a Pull Request."""
    await stream_log(
        ws,
        "INFO",
        "▶️ 🐙 [Git Injector] Establishing secure handshake with GitHub Repository...",
        trace_id,
    )

    def git_ops():
        g = Github(token)
        repo = g.get_repo(repo_name)
        default_branch = repo.get_branch(repo.default_branch)

        # Create Branch
        repo.create_git_ref(
            ref=f"refs/heads/{branch_name}", sha=default_branch.commit.sha
        )

        # Create Files
        for file_path, content in files.items():
            commit_msg = f"feat(analytics): Auto-provisioned BI asset for {user_email}"
            repo.create_file(file_path, commit_msg, content, branch=branch_name)

        # Open PR
        pr_body = f"🤖 **Sentinel-Insight Autonomous Generation**\n\n**Trace ID:** `{trace_id}`\n**Requested By:** `{user_email}`\n\nThis Pull Request contains Terraform IaC and JSON Schemas for a newly requested business analytics table targeted for `sentinel_marts`.\n\n### 🛡️ Governance Checklist\n- [x] **Strict Typing:** SQL enforces `SAFE_CAST` explicit data types.\n- [x] **Target Dataset:** Locked strictly to `sentinel_marts`.\n- [x] **Identity Labels:** `{user_email}` identity tagged on BigQuery resources.\n- [x] **Dry-Run Validation:** SQL successfully compiled against BigQuery without errors.\n\nPlease review before merging."
        pr = repo.create_pull(
            title=title, body=pr_body, head=branch_name, base=repo.default_branch
        )
        return pr.html_url

    pr_url = await asyncio.to_thread(git_ops)
    await stream_log(
        ws,
        "INFO",
        f"⏹️ 🐙 [Git Injector] Transmission complete. PR Created Successfully!",
        trace_id,
    )
    return pr_url


# ==============================================================================
# FASTAPI ENDPOINTS
# ==============================================================================
@app.get("/")
async def get():
    with open("static/index.html", "r") as f:
        return HTMLResponse(f.read())


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    trace_id = uuid.uuid4().hex[:8]

    # Extract identity from IAP/Cloud Run headers, fallback to mock if local
    headers = dict(websocket.headers)
    user_email = headers.get(
        "x-goog-authenticated-user-email", "local.developer@sentinel.ai"
    ).replace("accounts.google.com:", "")

    try:
        while True:
            data = await websocket.receive_text()
            payload = json.loads(data)

            intent = payload.get("intent", "").strip()
            chat_history = payload.get("history", [])
            action_override = payload.get(
                "action", None
            )  # Used for explicit confirmations
            target_sql = payload.get("sql", None)  # Used for explicit confirmations

            logger.info(f"[{trace_id}] Received Intent: {intent} from {user_email}")
            log_to_audit_table(
                trace_id,
                intent,
                "STARTED",
                {"action": "User submitted query"},
                user_email,
            )

            try:
                # ---------------------------------------------------------
                # HANDLE EXPLICIT CONFIRMATIONS Bypassing AI Drafting
                # ---------------------------------------------------------
                if action_override == "CONFIRM_EXPLORE" and target_sql:
                    html_table = await execute_and_format_results(
                        target_sql, trace_id, websocket
                    )
                    await websocket.send_json(
                        {
                            "status": "explore_result",
                            "message": "✅ Heavy query execution confirmed. Here are your insights:",
                            "html": html_table,
                            "sql": target_sql,
                        }
                    )
                    log_to_audit_table(
                        trace_id,
                        "CONFIRM_EXPLORE",
                        "SUCCESS",
                        {"action": "Heavy Data Explored"},
                        user_email,
                    )
                    continue

                elif action_override == "CONFIRM_BUILD" and target_sql:
                    # Rerun dry run just to get the schema for JSON formulation
                    _, _, _, _, schema_fields = await sandbox_dry_run_and_count(
                        target_sql, trace_id, websocket
                    )
                    table_name = f"insight_{trace_id}"

                    schema_json = await agent_draft_schema_json(
                        schema_fields, table_name, trace_id, websocket
                    )
                    json_path = f"infra/bigquery/tables/json/{table_name}.json"

                    hcl = await agent_draft_terraform(
                        target_sql,
                        table_name,
                        json_path,
                        user_email,
                        trace_id,
                        websocket,
                    )

                    if not GITHUB_TOKEN or not REPO_NAME:
                        raise Exception(
                            "Missing GITHUB_TOKEN or REPO_NAME in environment."
                        )

                    branch_name = f"ai/insight-marts-{trace_id}"
                    files = {
                        f"infra/analytics_views/{table_name}.tf": hcl,
                        json_path: schema_json,
                    }
                    pr_title = f"feat(analytics): Autonomous View Provisioning for {table_name} by {user_email}"

                    pr_url = await inject_and_create_pr(
                        REPO_NAME,
                        GITHUB_TOKEN,
                        branch_name,
                        files,
                        pr_title,
                        trace_id,
                        user_email,
                        websocket,
                    )

                    await websocket.send_json(
                        {
                            "status": "complete",
                            "message": f"✅ Terraform PR generated successfully for `sentinel_marts`. Labels tracked to {user_email}.",
                            "dashboard_url": pr_url,
                        }
                    )
                    log_to_audit_table(
                        trace_id,
                        "CONFIRM_BUILD",
                        "SUCCESS",
                        {"action": "PR Generated", "url": pr_url},
                        user_email,
                    )
                    continue

                # ---------------------------------------------------------
                # NORMAL FLOW: Classification & Drafting
                # ---------------------------------------------------------
                intent_type = await agent_classify_intent(intent, trace_id, websocket)

                if intent_type == "GREETING":
                    greeting_msg = (
                        f"Hello {user_email}! 👋 I am your autonomous Sentinel-Insight Data Engineer.\n\n"
                        "Here is what I can do for you today:\n"
                        "1️⃣ **Explore Data:** Ask me complex business questions. I will dynamically analyze our BigQuery tables, execute the query safely, and show you the results right here.\n"
                        "2️⃣ **Table Prioritization:** Tell me exactly which tables to use, or let me auto-discover them.\n"
                        "3️⃣ **Deploy Infrastructure:** If you like the results of an exploration, just ask me to 'Deploy this view'. I will autonomously write the Terraform IaC, enforce strict `SAFE_CAST` typing, apply identity labels, route it to `sentinel_marts`, and open a Pull Request for you!\n\n"
                        "How can I assist you?"
                    )
                    await websocket.send_json(
                        {"status": "greeting", "message": greeting_msg}
                    )
                    continue

                # Draft & Heal SQL
                sql = await agent_draft_sql(intent, chat_history, trace_id, websocket)

                is_valid, error_msg, cost, row_count, schema_fields = (
                    await sandbox_dry_run_and_count(sql, trace_id, websocket)
                )
                retry_count = 0
                while not is_valid and retry_count < 2:
                    sql = await agent_heal_sql(
                        intent, sql, error_msg, trace_id, websocket
                    )
                    is_valid, error_msg, cost, row_count, schema_fields = (
                        await sandbox_dry_run_and_count(sql, trace_id, websocket)
                    )
                    retry_count += 1

                if not is_valid:
                    raise Exception(
                        f"Failed to validate SQL after {retry_count} attempts. BQ Error: {error_msg}"
                    )

                # ---------------------------------------------------------
                # COST / ROW-LIMIT GUARDRAILS
                # ---------------------------------------------------------
                if row_count > 2000 or cost > 0.05:
                    warning_msg = f"⚠️ **High Volume Query Detected.**\nThis query will return **{row_count:,} records** and process data costing approximately **${cost:.4f}**.\nDo you want to proceed?"
                    await websocket.send_json(
                        {
                            "status": "confirmation_needed",
                            "message": warning_msg,
                            "sql": sql,
                            "intent_type": intent_type,
                        }
                    )
                    continue

                # ---------------------------------------------------------
                # EXECUTE INTENT (Safe limits)
                # ---------------------------------------------------------
                if intent_type == "EXPLORE":
                    html_table = await execute_and_format_results(
                        sql, trace_id, websocket
                    )
                    await websocket.send_json(
                        {
                            "status": "explore_result",
                            "message": "✅ Query executed safely. Here are your insights:",
                            "html": html_table,
                            "sql": sql,
                        }
                    )
                    log_to_audit_table(
                        trace_id,
                        intent,
                        "SUCCESS",
                        {"action": "Data Explored"},
                        user_email,
                    )

                elif intent_type == "BUILD":
                    table_name = f"insight_{trace_id}"
                    schema_json = await agent_draft_schema_json(
                        schema_fields, table_name, trace_id, websocket
                    )
                    json_path = f"infra/bigquery/tables/json/{table_name}.json"

                    hcl = await agent_draft_terraform(
                        sql, table_name, json_path, user_email, trace_id, websocket
                    )

                    if not GITHUB_TOKEN or not REPO_NAME:
                        raise Exception(
                            "Missing GITHUB_TOKEN or REPO_NAME in environment."
                        )

                    branch_name = f"ai/insight-marts-{trace_id}"
                    files = {
                        f"infra/analytics_views/{table_name}.tf": hcl,
                        json_path: schema_json,
                    }
                    pr_title = f"feat(analytics): Autonomous View Provisioning for {table_name} by {user_email}"

                    pr_url = await inject_and_create_pr(
                        REPO_NAME,
                        GITHUB_TOKEN,
                        branch_name,
                        files,
                        pr_title,
                        trace_id,
                        user_email,
                        websocket,
                    )

                    await websocket.send_json(
                        {
                            "status": "complete",
                            "message": f"✅ Terraform PR & JSON Schema generated successfully for `sentinel_marts`. Labels tracked to {user_email}.",
                            "dashboard_url": pr_url,
                        }
                    )
                    log_to_audit_table(
                        trace_id,
                        intent,
                        "SUCCESS",
                        {"action": "PR Generated", "url": pr_url},
                        user_email,
                    )

            except Exception as inner_e:
                error_str = str(inner_e)
                await stream_log(
                    websocket,
                    "ERROR",
                    f"☠️ [System Halt] Exception: {error_str}",
                    trace_id,
                    is_error=True,
                )
                log_to_audit_table(
                    trace_id, intent, "FAILED", {"error": error_str}, user_email
                )

    except WebSocketDisconnect:
        logger.info(f"[{trace_id}] Client disconnected.")
